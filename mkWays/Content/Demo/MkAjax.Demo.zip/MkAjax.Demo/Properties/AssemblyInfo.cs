﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("MkAjax.Demo")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("MkWays")]
[assembly: AssemblyProduct("MkAjax.Demo")]
[assembly: AssemblyCopyright("Martin Kostov Copyright ©  2014")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("ced63f08-b849-427c-b247-5a9dd878f0dd")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]